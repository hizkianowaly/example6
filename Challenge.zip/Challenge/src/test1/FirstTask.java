package test1;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class FirstTask {
	public WebDriver driver;
	String url = "https://www.techlistic.com/p/selenium-practice-form.html";
	
  @Test
  public void f() {
	  
	WebDriverWait wait = new WebDriverWait(driver, 30);
	
	//input firstname
	wait.until(ExpectedConditions.elementToBeClickable(By.name("firstname"))).sendKeys("TEST1");
	
	//input lastname
	wait.until(ExpectedConditions.elementToBeClickable(By.name("lastname"))).sendKeys("Tester");
	
	//select male
	wait.until(ExpectedConditions.elementToBeClickable(By.id("sex-0"))).click();
	
	//select 2 years
	wait.until(ExpectedConditions.elementToBeClickable(By.id("exp-1"))).click();
	
	//input datepicker
	wait.until(ExpectedConditions.elementToBeClickable(By.id("datepicker"))).sendKeys("5 Januari 2001");
	
	//select profession
	wait.until(ExpectedConditions.elementToBeClickable(By.id("profession-1"))).click();
	
	//select tool
	wait.until(ExpectedConditions.elementToBeClickable(By.id("tool-2"))).click();
	
	//select continent
	wait.until(ExpectedConditions.elementToBeClickable(By.id("continents"))).click();
	WebElement option = driver.findElement(By.id("continents"));
	option.findElement(By.xpath("//option[. = 'Australia']")).click();
	
	//click submit
	wait.until(ExpectedConditions.elementToBeClickable(By.id("submit"))).click();
	
	
  }
  @BeforeMethod
  public void beforeMethod() {
	driver = new FirefoxDriver();
	driver.get(url);
  }

  @AfterMethod
  public void afterMethod() {
  }

}
